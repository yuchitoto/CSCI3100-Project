//Code list:<open the JS console and input the following codes>
// variable
var netPrice;
var netWeight = 0;
netPrice = 1;
netWeight += 1;
var myStr = 'Hello world';
//Operation
netPrice ++;
var price = 'Price: '+ netPrice;
//function
function sayHello(){
   console.log("Hello");
}
function sayBye(name){
   console.log(name + ' bye!');
}
//Conditional statements
function detectSpam(input){
   input = input.toLowerCase();
   if(input.indexOf('fake') < 0) {
       return false;
   }
   return true;
}
//Array
var fruit = new Array('apple', 'lemon', 'banana');
var color = ['red', 'green', 'blue']        // the same to first definition, but shorter.
// Loop
for (var i = 0; i < 5; i++){
    console.log('count ' + i);
}
for(index in color){
    console.log(color[index]);
}
color.forEach(function(elem, index){     console.log(elem + ' '+ index);  
})
//Object
var profile = {
    name: 'Bob',
    age: 99,
    job: 'Freelance Hit',
}; // javascript is not a objective–oriented programming language, his Object definition is very straight forward. This structure is called JavaScript Object Notation
//Json: Json is a structure used very widely nowadays. And we will use json format intensively in web development, such as in communication between server and browser, database query and configurations. Basically, Json is consisted of key-value pairs. We can also turn string into json object. for example:
var text = '{"name": "Bob", "age": 99}';
var obj = JSON.parse(text);
obj.name;
//Json is also very powerful in representing hierarch structures
var text = '{"employees": {"name": "Alice"}}';
var obj = JSON.parse(text);
var text = '{"employees": [{"name": "Alice"}, {"name": "Bob"}]}';  // array
var obj = JSON.parse(text);

